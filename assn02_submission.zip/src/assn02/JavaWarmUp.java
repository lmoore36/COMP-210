package assn02;
import java.util.Scanner;

// Here is a starter code that you may optionally use for this assignment.
// TODO: You need to complete these sections

public class JavaWarmUp {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        String[] categoriesList = {"phone", "laptop", "smart_watch"};

        System.out.println("Program is running!");

        int n = s.nextInt();
        // MM/DD/YY, HH:MM, Name, Price, Quantity, Rating, Duration

        // create corresponding size arrays
        String dateT[] = new String[n];
        String timeT[] = new String[n];
        String categoryT[] = new String[n];
        double Assembling_fee[] = new double[n];
        int quantityT[] = new int[n];
        double Assembling_Time [] = new double[n];
        double Energy_and_Device_Cost [] = new double[n];

		// TODO: Fill in the above arrays with data entered from the console.
		// Your code starts here:

        s.nextLine();

        for (int i=0; i < n; i++){
            String line = s.nextLine();
            // System.out.println(line);
            String[] parts = line.split(" ");
            String date_str = parts[0];
            String time_str = parts[1];
            String category_str = parts[2];
            String assembling_fee_str = parts[3];
            String quantity_str = parts[4];
            String assembling_time_str = parts[5];
            String energy_and_device_cost_str = parts[6];

            dateT[i] = date_str;
            timeT[i] = time_str;
            categoryT[i] = category_str;
            Assembling_fee[i] = Double.parseDouble(assembling_fee_str);
            quantityT[i] = Integer.parseInt(quantity_str);
            Assembling_Time [i] = Double.parseDouble(assembling_time_str);
            Energy_and_Device_Cost [i] = Double.parseDouble(energy_and_device_cost_str);

            /* System.out.println("Date: " + date_str + " = " + dateT[i]);
            System.out.println("Time: " + time_str + " = " + timeT[i]);
            System.out.println("Category: " + category_str + " = " + categoryT[i]);
            System.out.println("Assembling Fee: " + assembling_fee_str + " = " + String.format("%f",Assembling_fee[i]));
            System.out.println("Quantity: " + quantity_str  + " = " + String.format("%d",quantityT[i]));
            System.out.println("Assembling Time: " + assembling_time_str  + " = " + String.format("%f",Assembling_Time[i]));
            System.out.println("Energy and Device Cost: " + energy_and_device_cost_str  + " = " + String.format("%f",Energy_and_Device_Cost[i]));
            System.out.println(); */
        }

		// Your code ends here.

        // Find items with highest and lowest price per unit
        int highestItemIndex = getMaxPriceIndex(Assembling_fee);
        int lowestItemIndex = getMinPriceIndex(Assembling_fee);

		// TODO: Print items with highest and lowest price per unit.
		// Your code starts here:

        System.out.println(dateT[highestItemIndex]);
        System.out.println(timeT[highestItemIndex]);
        System.out.println(categoryT[highestItemIndex]);
        System.out.println(Assembling_fee[highestItemIndex]);
        System.out.println(dateT[lowestItemIndex]);
        System.out.println(timeT[lowestItemIndex]);
        System.out.println(categoryT[lowestItemIndex]);
        System.out.println(Assembling_fee[lowestItemIndex]);

		// Your code ends here.

        // Calculate the average price, rating and duration of sales by category.
        // Maintain following category-wise stats in Arrays
        int[] numOfCategoriesC = new int[categoriesList.length];// so numOfCategoriesC[0] = # of categories of type categoriesList[0]
        double[] totPriceC = new double[categoriesList.length]; // total price of each category = sum(price x qty)
        int[] totQuantityC = new int[categoriesList.length];    // total qty of each category = sum (qty)
        double[] totAssembling_TimeC = new double[categoriesList.length]; // total Rating of each category = sum(price x qty)
        double[] totEnergy_and_Device_CostC = new double[categoriesList.length]; // total Duration of each category = sum(price x qty)


		// TODO: set the value of catIndex for each i to be such that categoryT[i] == categoriesList[i].
		// Your code starts here:

        for(int i=0; i < n; i++){
            if (categoryT[i].equals("phone")) {
                numOfCategoriesC[0] += 1;
                totQuantityC[0] += quantityT[i];
                totPriceC[0] += Assembling_fee[i] * quantityT[i];
                totAssembling_TimeC[0] += Assembling_Time[i];
                totEnergy_and_Device_CostC[0] += Energy_and_Device_Cost[i];
            }
            if (categoryT[i].equals("laptop")) {
                numOfCategoriesC[1] += 1;
                totQuantityC[1] += quantityT[i];
                totPriceC[1] += Assembling_fee[i] * quantityT[i];
                totAssembling_TimeC[1] += Assembling_Time[i];
                totEnergy_and_Device_CostC[1] += Energy_and_Device_Cost[i];
            }
            if (categoryT[i].equals("smart_watch")) {
                numOfCategoriesC[2] += 1;
                totQuantityC[2] += quantityT[i];
                totPriceC[2] += Assembling_fee[i] * quantityT[i];
                totAssembling_TimeC[2] += Assembling_Time[i];
                totEnergy_and_Device_CostC[2] += Energy_and_Device_Cost[i];
            }
        }
		// Your code ends here.

		// TODO: Calculate & Print Category-wise Statistics
		// Your code starts here:

        for(int i = 0; i < categoriesList.length; i++ ){
            double avg_price = 0;
            double avg_profit = 0;

            avg_price = totPriceC[i] / totQuantityC[i];
            avg_profit = (totPriceC[i] - totEnergy_and_Device_CostC[i] - (totAssembling_TimeC[i] * 16)) / totQuantityC[i];

            System.out.println(categoriesList[i]);
            System.out.println(totQuantityC[i]);
            System.out.println(String.format("%.2f", avg_price));
            System.out.println(String.format("%.2f", avg_profit));

        }
		// Your code ends here.
    }

    // TODO: Find index of item with the highest price per unit.
    static int getMaxPriceIndex(double[] priceT){
		// Your code starts here:
        double highest_price = priceT[0];
        int highest_price_idx = 0;

        for (int i=0; i < priceT.length; i++) {
            if (priceT[i] >= highest_price){
                highest_price = priceT[i];
                highest_price_idx = i;
            }
        }
        return(highest_price_idx); // modify this as well
		// Your code ends here.
    }

    // TODO: Find index of item with the lowest price per unit.
    static int getMinPriceIndex(double[] priceT){
		// Your code starts here:
        double lowest_price = priceT[0];
        int lowest_price_idx = 0;

        for (int i=0; i < priceT.length; i++) {
            if (priceT[i] <= lowest_price){
                lowest_price = priceT[i];
                lowest_price_idx = i;
            }
        }

        return(lowest_price_idx); // modify this as well
		// Your code ends here.
    }
}
